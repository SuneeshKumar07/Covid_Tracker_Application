# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'HomewosMDa.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *

import Home.ui

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(799, 605)
        MainWindow.setStyleSheet(u"background-color: white;")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.label_2 = QLabel(self.centralwidget)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setGeometry(QRect(160, 50, 101, 31))
        self.label_2.setStyleSheet(u"color: Black;\n"
"Font-size:15px;\n"
"letter-spacing:1.2px;\n"
"border:2px solid cyan;\n"
"border-radius:10px;\n"
"background:none;\n"
"font-weight:bold;\n"
"color:white;")
        self.label_2.setAlignment(Qt.AlignCenter)
        self.label_3 = QLabel(self.centralwidget)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setGeometry(QRect(270, 50, 111, 31))
        self.label_3.setStyleSheet(u"color: Black;\n"
"Font-size:15px;\n"
"letter-spacing:1.2px;\n"
"border:2px solid cyan;\n"
"border-radius:10px;\n"
"background:none;\n"
"font-weight:bold;\n"
"color:white;")
        self.label_3.setAlignment(Qt.AlignCenter)
        self.label_4 = QLabel(self.centralwidget)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setGeometry(QRect(400, 50, 101, 31))
        self.label_4.setStyleSheet(u"color: Black;\n"
"Font-size:15px;\n"
"letter-spacing:1.2px;\n"
"border:2px solid cyan;\n"
"border-radius:10px;\n"
"background:none;\n"
"font-weight:bold;\n"
"color:white;")
        self.label_4.setAlignment(Qt.AlignCenter)
        self.label_5 = QLabel(self.centralwidget)
        self.label_5.setObjectName(u"label_5")
        self.label_5.setGeometry(QRect(510, 50, 111, 31))
        self.label_5.setStyleSheet(u"color: Black;\n"
"Font-size:15px;\n"
"letter-spacing:1.2px;\n"
"border:2px solid cyan;\n"
"border-radius:10px;\n"
"background:none;\n"
"font-weight:bold;\n"
"color:white;")
        self.label_5.setAlignment(Qt.AlignCenter)
        self.pushButton = QPushButton(self.centralwidget)
        self.pushButton.setObjectName(u"pushButton")
        self.pushButton.setGeometry(QRect(680, 10, 91, 41))
        self.pushButton.setStyleSheet(u"\n"
"    background: blue;\n"
"    border:2px solid black;\n"
"	border-radius:15px;\n"
"    color:#fff;\n"
"    font-size: 15px;\n"
"    letter-spacing: 2px;\n"
"    font-family: 'Lato';\n"
"    font-weight: 200;\n"
" \n"
"")
        self.pushButton_2 = QPushButton(self.centralwidget)
        self.pushButton_2.setObjectName(u"pushButton_2")
        self.pushButton_2.setGeometry(QRect(680, 80, 101, 41))
        self.pushButton_2.setStyleSheet(u"    background: #F8B97A;\n"
"    border:2px solid black;\n"
"	border-radius:15px;\n"
"    color:Black;\n"
"    font-size: 15px;\n"
"    letter-spacing: 0.5px;\n"
"    font-family: 'Lato';\n"
"    font-weight: 200;\n"
"")
        self.label_6 = QLabel(self.centralwidget)
        self.label_6.setObjectName(u"label_6")
        self.label_6.setGeometry(QRect(30, 10, 71, 81))
        self.label_6.setMouseTracking(True)
        self.label_6.setStyleSheet(u"background:none")
        self.label_6.setPixmap(QPixmap(u"cov.png"))
        self.label_6.setScaledContents(True)
        self.label_6.setWordWrap(False)
        self.label_7 = QLabel(self.centralwidget)
        self.label_7.setObjectName(u"label_7")
        self.label_7.setGeometry(QRect(10, 90, 141, 31))
        self.label_7.setStyleSheet(u"color:White;\n"
"Font-size:15px;\n"
"letter-spacing:0.5px;\n"
"background:none")
        self.label_16 = QLabel(self.centralwidget)
        self.label_16.setObjectName(u"label_16")
        self.label_16.setGeometry(QRect(0, 0, 801, 581))
        self.label_16.setStyleSheet(u"")
        self.label_16.setPixmap(QPixmap(u"image (2).png"))
        self.label_16.setScaledContents(True)
        self.label = QLabel(self.centralwidget)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(320, 100, 161, 31))
        self.label.setStyleSheet(u"color: Black;\n"
"Font-size:25px;\n"
"letter-spacing:1.2px;\n"
"background:none;\n"
"font-weight:bold;\n"
"color:white;")
        self.label_8 = QLabel(self.centralwidget)
        self.label_8.setObjectName(u"label_8")
        self.label_8.setGeometry(QRect(660, 140, 111, 31))
        self.label_8.setStyleSheet(u"color: Black;\n"
"Font-size:12px;\n"
"letter-spacing:1.2px;\n"
"border:2px solid cyan;\n"
"border-radius:10px;\n"
"background:none;\n"
"font-weight:bold;\n"
"color:white;")
        self.label_9 = QLabel(self.centralwidget)
        self.label_9.setObjectName(u"label_9")
        self.label_9.setGeometry(QRect(40, 160, 191, 131))
        self.label_9.setStyleSheet(u"color: Black;\n"
"Font-size:15px;\n"
"letter-spacing:1.2px;\n"
"background:none;\n"
"font-weight:bold;\n"
"color:white;")
        self.label_9.setPixmap(QPixmap(u"../1.png"))
        self.label_9.setScaledContents(True)
        self.label_10 = QLabel(self.centralwidget)
        self.label_10.setObjectName(u"label_10")
        self.label_10.setGeometry(QRect(60, 280, 171, 16))
        self.label_10.setStyleSheet(u"color: Black;\n"
"Font-size:15px;\n"
"letter-spacing:1.2px;\n"
"background:none;\n"
"font-weight:bold;\n"
"color:white;")
        self.label_11 = QLabel(self.centralwidget)
        self.label_11.setObjectName(u"label_11")
        self.label_11.setGeometry(QRect(190, 290, 241, 221))
        self.label_11.setStyleSheet(u"color: Black;\n"
"Font-size:15px;\n"
"letter-spacing:1.2px;\n"
"background:none;\n"
"font-weight:bold;\n"
"color:white;")
        self.label_11.setPixmap(QPixmap(u"../2.png"))
        self.label_12 = QLabel(self.centralwidget)
        self.label_12.setObjectName(u"label_12")
        self.label_12.setGeometry(QRect(130, 430, 521, 51))
        self.label_12.setStyleSheet(u"color: Black;\n"
"Font-size:15px;\n"
"letter-spacing:1.2px;\n"
"background:none;\n"
"font-weight:bold;\n"
"color:white;")
        self.label_13 = QLabel(self.centralwidget)
        self.label_13.setObjectName(u"label_13")
        self.label_13.setGeometry(QRect(170, 470, 231, 16))
        self.label_13.setStyleSheet(u"color: Black;\n"
"Font-size:15px;\n"
"letter-spacing:1.2px;\n"
"background:none;\n"
"font-weight:bold;\n"
"color:white;")
        self.label_14 = QLabel(self.centralwidget)
        self.label_14.setObjectName(u"label_14")
        self.label_14.setGeometry(QRect(400, 150, 231, 191))
        self.label_14.setStyleSheet(u"color: Black;\n"
"Font-size:15px;\n"
"letter-spacing:1.2px;\n"
"background:none;\n"
"font-weight:bold;\n"
"color:white;")
        self.label_14.setPixmap(QPixmap(u"../3.png"))
        self.label_15 = QLabel(self.centralwidget)
        self.label_15.setObjectName(u"label_15")
        self.label_15.setGeometry(QRect(390, 300, 241, 16))
        self.label_15.setStyleSheet(u"color: Black;\n"
"Font-size:15px;\n"
"letter-spacing:1.2px;\n"
"background:none;\n"
"font-weight:bold;\n"
"color:white;")
        self.label_17 = QLabel(self.centralwidget)
        self.label_17.setObjectName(u"label_17")
        self.label_17.setGeometry(QRect(420, 320, 181, 16))
        self.label_17.setStyleSheet(u"color: Black;\n"
"Font-size:15px;\n"
"letter-spacing:1.2px;\n"
"background:none;\n"
"font-weight:bold;\n"
"color:white;")
        self.label_18 = QLabel(self.centralwidget)
        self.label_18.setObjectName(u"label_18")
        self.label_18.setGeometry(QRect(550, 340, 201, 171))
        self.label_18.setStyleSheet(u"color: Black;\n"
"Font-size:15px;\n"
"letter-spacing:1.2px;\n"
"background:none;\n"
"font-weight:bold;\n"
"color:white;")
        self.label_18.setPixmap(QPixmap(u"../4.png"))
        self.label_19 = QLabel(self.centralwidget)
        self.label_19.setObjectName(u"label_19")
        self.label_19.setGeometry(QRect(540, 480, 231, 16))
        self.label_19.setStyleSheet(u"color: Black;\n"
"Font-size:15px;\n"
"letter-spacing:1.2px;\n"
"background:none;\n"
"font-weight:bold;\n"
"color:white;")
        MainWindow.setCentralWidget(self.centralwidget)
        self.label_16.raise_()
        self.label_2.raise_()
        self.label_3.raise_()
        self.label_4.raise_()
        self.label_5.raise_()
        self.pushButton.raise_()
        self.pushButton_2.raise_()
        self.label_6.raise_()
        self.label_7.raise_()
        self.label.raise_()
        self.label_8.raise_()
        self.label_9.raise_()
        self.label_10.raise_()
        self.label_11.raise_()
        self.label_12.raise_()
        self.label_13.raise_()
        self.label_14.raise_()
        self.label_15.raise_()
        self.label_17.raise_()
        self.label_18.raise_()
        self.label_19.raise_()
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 799, 26))
        MainWindow.setMenuBar(self.menubar)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.label_2.setText(QCoreApplication.translate("MainWindow", u"Home", None))
        self.label_3.setText(QCoreApplication.translate("MainWindow", u"Precaution", None))
        self.label_4.setText(QCoreApplication.translate("MainWindow", u"Latest", None))
        self.label_5.setText(QCoreApplication.translate("MainWindow", u"Stats", None))
        self.pushButton.setText(QCoreApplication.translate("MainWindow", u"Login", None))
        self.pushButton_2.setText(QCoreApplication.translate("MainWindow", u"Help Lines", None))
        self.label_6.setText("")
        self.label_7.setText(QCoreApplication.translate("MainWindow", u"|| Covid Tracker ||", None))
        self.label_16.setText("")
        self.label.setText(QCoreApplication.translate("MainWindow", u"Precautions", None))
        self.label_8.setText(QCoreApplication.translate("MainWindow", u"Myth-Busters", None))
        self.label_9.setText("")
        self.label_10.setText(QCoreApplication.translate("MainWindow", u"WEAR FACE MASK", None))
        self.label_11.setText("")
        self.label_12.setText(QCoreApplication.translate("MainWindow", u" WASH YOUR HANDS FREQUENTLY ", None))
        self.label_13.setText(QCoreApplication.translate("MainWindow", u"WITH SOAP AND WATER ", None))
        self.label_14.setText("")
        self.label_15.setText(QCoreApplication.translate("MainWindow", u"DO NOT TOUCH YOUR EYES", None))
        self.label_17.setText(QCoreApplication.translate("MainWindow", u"WITH DIRTY HANDS", None))
        self.label_18.setText("")
        self.label_19.setText(QCoreApplication.translate("MainWindow", u"USE TISSUE WHEN SNEEZE/COUGH", None))
    # retranslateUi

